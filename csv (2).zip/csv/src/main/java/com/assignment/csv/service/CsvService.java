package com.assignment.csv.service;

import java.nio.file.Path;

public interface CsvService {
	
	public void upload(Path path);

}
