package com.assignment.csv.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.assignment.csv.model.Student;

@Service
public class CsvServiceImpl implements CsvService {
	
	final String xmlFilePath = "C:\\Users\\91966\\Downloads\\csv\\src\\main\\resources\\";

	@Override
	public void upload(Path path) {
		List<Student> stu = new ArrayList<>();   
		try (Stream<String> lines = Files.lines(path)) {
			lines.forEach(s -> {
				String[] strArray = s.split(",");
				Student student = new Student();
				student.setId(strArray[0]);
				student.setName(strArray[1]);
				student.setSubject(strArray[2]);
				student.setMarks(strArray[3]);
				stu.add(student);
		});
		} catch (IOException e) {
			e.printStackTrace();
		} 
		createDoc(stu);
	}

	private void createDoc(List<Student> stu) {
		Map<String, List<Student>> StuByName = new HashMap<>();
		StuByName = stu.stream().collect(Collectors.groupingBy(Student::getName));
		StuByName.entrySet().stream().forEach(e -> {
			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = null;
			try {
				documentBuilder = documentFactory.newDocumentBuilder();
			} catch (ParserConfigurationException e1) {
				e1.printStackTrace();
			}
			Document document = documentBuilder.newDocument();
			Element root = document.createElement("students");
			document.appendChild(root);
			AtomicInteger j = new AtomicInteger();
			Element student = document.createElement("student");
			root.appendChild(student);
			Element name = document.createElement("name");
			name.appendChild(document.createTextNode(e.getKey()));
			student.appendChild(name);
			e.getValue().forEach(s -> {

				Element sub1 = document.createElement("subject" + j.incrementAndGet());
				sub1.appendChild(document.createTextNode(s.getSubject() + "," + s.getMarks()));
				student.appendChild(sub1);

			});
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = null;
			try {
				transformer = transformerFactory.newTransformer();
			} catch (TransformerConfigurationException e1) {

				e1.printStackTrace();
			}
			DOMSource domSource = new DOMSource(document);
			StreamResult streamResult = new StreamResult(new File(xmlFilePath + e.getKey() + ".xml"));

			try {
				transformer.transform(domSource, streamResult);
			} catch (TransformerException e2) {

				e2.printStackTrace();
			}
		});
	}

}
