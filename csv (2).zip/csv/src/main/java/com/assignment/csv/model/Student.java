package com.assignment.csv.model;

import lombok.Data;

@Data
public class Student {
	
	private String id;
	private String name;
	private String subject;
	private String marks;
	public Student(String id, String name, String subject, String marks) {
		super();
		this.id = id;
		this.name = name;
		this.subject = subject;
		this.marks = marks;
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", subject=" + subject + ", marks=" + marks + "]";
	}
	
	

}
